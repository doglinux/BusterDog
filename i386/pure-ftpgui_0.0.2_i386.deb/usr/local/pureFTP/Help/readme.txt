Pure-FTP 1.0.22

Pure-FTPd is a fast, production-quality, standard-conformant FTP server

There is a pureFTP icon in my-roxapps.
Click the icon to start/stop the ftp server.
Right click the icon for Help.
Delete the icon to uninstall.

The authentication database is 2 files in /etc:
/etc/pureftpd.passwd
/etc/pureftpd.pdb

If pureftpd.passwd does not exist, a new default user
will be created:
user name: puppyftp
password:  rox
file dir:  /root/puppyftp/

The users file dir will automatically be created
the first time the user logs in.

To create a new user, type:
pure-pw useradd puppyftp -u nobody -d/root/puppyftp/

To remove a user, type:
pure-pw userdel puppyftp

To see the configuration dtails of a user, type:
pure-pw show puppyftp

To see a list of users, type:
pure-pw list

To compile the database, type:
pure-pw mkdb

NOTE: AFTER MAKING CHANGES TO THE AUTHENTICATION DATABASE,
YOU MUST TYPE: pure-pw mkdb FOR THE CHANGES TO TAKE EFFECT.

Note: the server is configured to not allow anonymous logins,
and to not allow login by user "root" ... you can change this by editing /root/my-roxapps/pureFTP/AppRun or run pure-ftpd with the options you like, from the command line.

Read the documentation, especially pure-pw.htm

You can access the server using a web browser at e.g. this address:
.
ftp://puppyftp:rox@127.0.0.1/
ftp://ftpuser:dog@localhost/
ftp://user:dog@127.0.0.1/
ftp://ftp@127.0.0.1/

For anonymous:
ftp://anonymous@127.0.0.1/

To access the server from outside of your machine,
change 127.0.0.1 to your own IP address.

You need to open suitable ports for your server to work properly.

Of course, you can configure your own list of users.

Logfile: /var/log/pureftpd.log

-----

Configuration options:

./configure --with-minimal --without-inetd --without-pam --with-puredb --with-altlog

=====
GuestToo - Nov 20, 2006
